

-----------------------------How To Start--------------------------

1. Open Command prompt
2. Then change path to the directory where the project is saved
3. Open the Project folder using cd command
4. Use npm install to install the application
5. Now simply open the index.html file given in the project folder
6. Your project is now working

-----------------------Why we dont need a server-------------------
The react application dont need a server for their running
We just made a file that includes all the necessary 
script tags that is required to run the react application.
So, just open the index.html file and enjoy the gaming.


HAPPY GAMING! :)